/**
 *  This class contains subclasses of AsyncImage
 */
package com.codename1.rad.ui.image;


/**
 *  An image loaded from file system storage.
 *  @author shannah
 */
public class FileSystemImage extends AsyncImage {

	public FileSystemImage(com.codename1.io.File file) {
	}

	public com.codename1.io.File getFile() {
	}
}

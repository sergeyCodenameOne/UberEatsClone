/**
 *  This class contains menu components that can be bound to Actions and Action lists.
 */
package com.codename1.rad.ui.menus;


/**
 *  A popup menu for rendering a list of actions.
 *  @author shannah
 */
public class PopupActionsMenu extends ca.weblite.shared.components.PopupMenu {

	public PopupActionsMenu(com.codename1.rad.ui.Actions actions, com.codename1.rad.models.Entity entity, com.codename1.ui.Component source) {
	}
}

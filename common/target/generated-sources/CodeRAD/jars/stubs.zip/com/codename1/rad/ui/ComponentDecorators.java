/**
 *  This package contains the foundation classes for CodeRAD views.  Nodes, Attributes, UI descriptors, etc..
 */
package com.codename1.rad.ui;


/**
 * 
 *  @author shannah
 */
public class ComponentDecorators extends NodeList {

	public ComponentDecorators(NodeList nodes) {
	}

	@java.lang.Override
	public void add(com.codename1.rad.nodes.Node[] nodes) {
	}

	public void decorate(com.codename1.ui.Component cmp) {
	}
}

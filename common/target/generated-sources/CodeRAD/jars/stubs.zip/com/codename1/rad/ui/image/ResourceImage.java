/**
 *  This class contains subclasses of AsyncImage
 */
package com.codename1.rad.ui.image;


/**
 *  An image that is loaded from a resource file.
 *  @author shannah
 */
public class ResourceImage extends AsyncImage {

	public ResourceImage(com.codename1.ui.util.Resources res, String imageName) {
	}

	public com.codename1.ui.util.Resources getResources() {
	}

	public String getImageName() {
	}
}

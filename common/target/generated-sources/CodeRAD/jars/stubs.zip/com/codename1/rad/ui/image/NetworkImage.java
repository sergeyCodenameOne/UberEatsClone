/**
 *  This class contains subclasses of AsyncImage
 */
package com.codename1.rad.ui.image;


/**
 *  An image that is loaded over the network.
 *  @author shannah
 */
public class NetworkImage extends AsyncImage {

	public NetworkImage(String url) {
	}

	public String getURL() {
	}
}
